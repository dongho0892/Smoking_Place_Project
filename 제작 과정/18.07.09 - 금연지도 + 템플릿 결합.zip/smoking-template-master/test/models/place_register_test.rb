require 'test_helper'

class PlaceRegisterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
