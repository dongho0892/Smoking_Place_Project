class SmokingArea < ApplicationRecord
end
