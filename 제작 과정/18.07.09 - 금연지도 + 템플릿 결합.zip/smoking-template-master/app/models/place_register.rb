class PlaceRegister < ApplicationRecord
end
